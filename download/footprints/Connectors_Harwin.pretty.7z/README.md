# Connectors_Harwin.pretty

This library contains footprints for various Harwin connectors - https://www.harwin.com/