# Symbols.pretty

Graphical symbols for placement on PCB.
