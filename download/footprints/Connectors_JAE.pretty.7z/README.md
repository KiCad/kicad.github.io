# Connectors_JAE.pretty

This repository contains KiCad footprints for JAE PCB connectors

http://www.jae.com/jccom/en/connectors
