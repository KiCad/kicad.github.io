# Connectors_Hirose.pretty

This library contains footprints for Hirose connectors - https://www.hirose.com/

Footprints for the following connectors are available:
* **DF13** - https://www.hirose.com/product/en/products/DF13
* **DF52** - https://www.hirose.com/product/en/products/DF52/
* **DF63** - https://www.hirose.com/product/en/products/DF63/
