# Connectors_Terminal_Blocks.pretty

This repository contains deprecated footprints for various terminal blocks.

Terminal blocks are now sorted by manufacturer. The footprints in this library can now be found here:

* https://github.com/KiCad/TerminalBlock_Phoenix.pretty
* https://github.com/KiCad/TerminalBlock_WAGO.pretty
* https://github.com/KiCad/TerminalBlock_Philmore.pretty
* https://github.com/KiCad/TerminalBlock_RND.pretty
* https://github.com/KiCad/TerminalBlock_4UCON.pretty
