# LEDs.pretty

This library contains PCB footprints for various LEDs (light emitting diodes) and associated devices


Currently, each footprint library is hosted on GitHub as an individual repository. This is unmaintainable and these libraries will be merged (here) for the v5 KiCad release.
