# Valves.pretty

## Note

This repository is read-only and will not accept further contributions. Any new contributions should be made to the new [kicad-footprints](https://github.com/kicad/kicad-footprints) repository.
