# Antennas.pretty
Footprints for various antennas

## Note

This repository is now read-only and will not accept any further pull requests. To contribute, refer to the new footprints library at https://github.com/kicad/kicad-footprints
