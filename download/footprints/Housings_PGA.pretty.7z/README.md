# Housings_PGA.pretty

This repository contains various Pin-Grid-Array packages - https://en.wikipedia.org/wiki/Pin_grid_array
