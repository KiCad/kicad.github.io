# Housings_PGA.pretty

This repository contains various Pin-Grid-Array packages - https://en.wikipedia.org/wiki/Pin_grid_array


## Note

This repository is now considered legacy in preparation for the v5 KiCad software release. It will not accept any further pull requests. To contribute, please refer to the new `kicad-footprints` repository at https://github.com/kicad/kicad-footprints
