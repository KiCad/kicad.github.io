# Connectors_USB.pretty
USB (Universal Serial Bus) connector footprints
