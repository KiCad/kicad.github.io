# Diodes_SMD.pretty
Surface mount diode footprints
This is a legacy repo for kicad v4. No new pull requests will be accepted here. Replacement repo: https://github.com/KiCad/kicad-footprints
