# Connectors_Card.pretty

Footprints for cards and card holders
