# Connectors_IDC.pretty
IDC connector footprints

## Note

This repository is now marked as read-only and will not accept any further pull requests. To contribute, please refer to the new footprints repository at https://github.com/kicad/kicad-footprints
