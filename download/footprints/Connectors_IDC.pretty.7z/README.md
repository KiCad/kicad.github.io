# Connectors_IDC.pretty
IDC connector footprints
