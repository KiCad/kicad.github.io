# Housings_QFP.pretty

This repository contains various Quad-Flat-Package footprints - https://en.wikipedia.org/wiki/Quad_Flat_Package


## Note

This repository is now considered legacy in preparation for the v5 KiCad software release. It will not accept any further pull requests. To contribute, please refer to the new `kicad-footprints` repository at https://github.com/kicad/kicad-footprints
