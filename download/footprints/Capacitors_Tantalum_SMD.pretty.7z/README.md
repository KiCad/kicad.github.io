# Capacitors_Tantalum_SMD.pretty

This is a legacy repo for kicad v4. No new pull requests will be accepted here.
Replacement repo: https://github.com/KiCad/kicad-footprints
