# Connectors_Molex.pretty

This library contains PCB footprints for Molex connectors - http://www.molex.com/molex/home
