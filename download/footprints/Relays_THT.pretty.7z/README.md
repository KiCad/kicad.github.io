# Relays_THT.pretty
Footprints for through-hole relays

## Note

This repository is now marked as read-only and will no longer accept any new PRs. To contribute, refer to the new footprint libraries repository at https://github.com/kicad/kicad-footprints
