# Inductors_THT.pretty
Through hole inductor footprints
