# Enclosures.pretty
Footprints for common electronics enclosures
