# Hall-Effect_Transducers_LEM.pretty

## Note

This repository is now read-only and will not accept any further Pull Requests. To contrubite, refer to the new footprint library at https://github.com/kicad/kicad-footprints
