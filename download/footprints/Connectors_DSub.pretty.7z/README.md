### Connectors_DSub

Footprints for DB / Dsubmiature / MicroD footprints

## NOTE:

This repository is locked and will not accept any more pull requests. These footprints can now be found at the new https://github.com/kicad/kicad-footprints repository.
