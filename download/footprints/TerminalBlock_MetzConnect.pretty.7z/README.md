# TerminalBlock_MetzConnect.pretty
Metz-Connect (http://www.metz-connect.com) terminal block footprints

## Note

This repository is now read only and will not accept any further Pull Requests.

To contribute, please refer to the new footprints repository at https://github.com/kicad/kicad-footprints
