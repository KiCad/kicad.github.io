# Fiducials.pretty

Fiducial and location markers

## Note

This repository is locked and will not accept any further pull requests. Please refer to the new footprints repository at https://github.com/KiCad/kicad-footprints
