# Housings_SSOP.pretty

This repository contains footprints for various SSOP / TSSOP packages - https://en.wikipedia.org/wiki/Small_Outline_Integrated_Circuit#SSOP

## Note

This repository is now considered legacy in preparation for the v5 KiCad software release. It will not accept any further pull requests. To contribute, please refer to the new `kicad-footprints` repository at https://github.com/kicad/kicad-footprints
