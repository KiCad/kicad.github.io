# TerminalBlock_Dinkle.pretty

Dinkle terminal block, https://www.dinkle.com/
