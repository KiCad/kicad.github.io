# Socket_Strips.pretty

This repository is locked and will not accept any further pull requests. Please refer to the new footprints repository at https://github.com/KiCad/kicad-footprints
