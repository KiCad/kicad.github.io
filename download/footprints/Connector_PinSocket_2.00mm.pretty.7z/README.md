# Conn_PinSocket_2.00mm.pretty

These footprints have been script-generated with a python script available at https://github.com/pointhi/kicad-footprint-generator/scripts/Conn_PinSocket

NOTE: the footprints carried over from KiCad 4.0.7 retains their original dimensions
