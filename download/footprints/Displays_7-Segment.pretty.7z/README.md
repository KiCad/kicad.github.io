# Displays_7-Segment.pretty


## Note

This repository is now marked as `legacy` and will not accept any further pull requests. To contribute, please refer to the new `kicad-footprints` repository at http://github.com/kicad/kicad-footprints
