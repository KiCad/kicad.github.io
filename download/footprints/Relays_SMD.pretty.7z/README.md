# Relays_SMD.pretty

This library contains footprints for surface-mount relays
