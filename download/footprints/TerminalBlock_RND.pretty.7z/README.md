# TerminalBlock_RND.pretty
RND terminal block footprints

## Note

This repository is now read only and will not accept any further Pull Requests.

To contribute, please refer to the new footprints repository at https://github.com/kicad/kicad-footprints
