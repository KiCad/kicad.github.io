# Housings_LLC.pretty
Leaded Chip Carrier (LCC) footprints, such as PLCC (Plastic Leaded Chip Carrier), see https://en.wikipedia.org/wiki/Chip_carrier#Plastic_leaded_chip_carrier


## Note

This repository is now considered legacy in preparation for the v5 KiCad software release. It will not accept any further pull requests. To contribute, please refer to the new `kicad-footprints` repository at https://github.com/kicad/kicad-footprints
