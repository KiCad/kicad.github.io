# Conn_Molex.pretty
Footprints for connectors by Molex

## Created with general smd single row connector generator

 - Panelmate
 - Pico-EZmate
 - Pico-EZmate Slim
 - PicoBlade
 - Pico-Clasp
 - CLIK-Mate

Script details:
- author: Poeschl Rene
- script location: https://github.com/pointhi/kicad-footprint-generator/tree/master/scripts/Connector_SMD_single_row_plus_mounting_pad/
- used config file: config_KLCv3.0.yaml
- series description file: conn_Molex.yaml
- python version: 3.6.2

 ---
