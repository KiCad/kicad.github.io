## Footprint Library Credits

The credits of 3D models are listed in respective folder.  
Please fill all 3D models credits and info source data accordingly.  

### Info requirements:
- Author
- if the 3D model is script generated, a link to the script generator is required as well as the version and sw used
- if the 3D model is manually generated, include the source model @ https://github.com/KiCad/packages3D-source

<hr>  

### Buttons_Switches_THT:  
main author: Joan Obijuan, Rene Poeschl and Frank Shackmeister (others in script files)

release version of sw used to create models:  
- FreeCAD 0.15 or FreeCAD 0.17 release >= 10647

USB_Micro-B_Molex_47346-0001 - manually made by Obijuan, adjusted for Kicad by Shack