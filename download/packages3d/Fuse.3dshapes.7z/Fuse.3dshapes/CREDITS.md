## Footprint Library Credits

The credits of 3D models are listed in respective folder.  
Please fill all 3D models credits and info source data accordingly.  

### Info requirements:
- Author
- if the 3D model is script generated, a link to the script generator is required as well as the version and sw used
- if the 3D model is manually generated, include the source model @ https://github.com/KiCad/packages3D-source

### Fuse_Holders_and_Fuses.3dshapes

#### Fuseholder_Cylinder-5x20mm-or-6.3x32mm_Schurter_FUP_0031.25x0_Horizontal_Closed.step and Fuseholder_Cylinder-5x20mm-or-6.3x32mm_Schurter_FUP_0031.25x0_Horizontal_Closed.wrl
main author: Rene Pöschl
release version of sw used to create models:  
- FreeCAD 0.17
- KiCad Stepup
